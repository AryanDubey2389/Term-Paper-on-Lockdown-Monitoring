import pygame
yel=[255, 255, 0]
x = 540
y = 760
xi=540
yi= 0
temp1=9
width = 30
height = 15
vel = 10
red = [255 , 0, 0]
d = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
dis = 0
p=0
t=0
i=0
s=""
f=0
v=0
temp2=[]
temp2.append(0)
champ1=pygame.image.load("img1.png")
champ1=pygame.transform.scale(champ1,(70,30))
champ2=pygame.image.load("img1.png")
champ2=pygame.transform.scale(champ2,(70,30))