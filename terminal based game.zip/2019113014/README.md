Open main.py to run the game
Basic controls of the game :-
a - to move the paddle left
d - to move the paddle right
e - to quit the game 
m - to move the brick down

Basic rule:-
You are given 3 lifes to play the game . If you will lost those files you will lose your game.
In this game you have to break all the bricks by your ball.

Oops concept:-
Inheritance
The types different types of brick inherits the Brick class.

Polymorphism
The conept of polymorphism is also used in the code to make it more effective in most of the places.

Encapsulation
The entire game is modelled using classes and objects which encapsulate logically different entities.

Abstraction
Many methods are used to abstract away the details and make the code more readable and organised like moveballleft() and moveballright().